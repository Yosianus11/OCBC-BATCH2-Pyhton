from flask import make_response, abort
from config import db
from models import Director, Movie, MovieSchema


def read_all():
    # Query the database for all the notes
    movies = Movie.query.order_by(db.desc(Movie.release_date)).limit(10)

    # Serialize the list of notes from our data
    movie_schema = MovieSchema(many=True)
    data = movie_schema.dump(movies)
    return data

def read_one(directors_id, movie_id):
    # Query the database for the note
    movie = (
        Movie.query.join(Director, Director.id == Movie.director_id)
        .filter(Director.id == directors_id)
        .filter(Movie.id == movie_id)
        .one_or_none()
    )

    # Was a note found?
    if movie is not None:
        note_schema = MovieSchema()
        data = note_schema.dump(movie)
        return data

    # Otherwise, nope, didn't find that note
    else:
        abort(404, f"Movie not found for Id: {movie_id}")


def create(director_id, movie):

    # get the parent person
    director = Director.query.filter(Director.id == director_id).one_or_none()

    # Was a person found?
    if director is None:
        abort(404, f"Person not found for Id: {director_id}")

    # Create a note schema instance
    schema = MovieSchema()
    new_movie = schema.load(movie, session=db.session)

    # Add the note to the person and database
    director.movies.append(new_movie)
    db.session.commit()

    # Serialize and return the newly created note in the response
    data = schema.dump(new_movie)

    return data, 201


