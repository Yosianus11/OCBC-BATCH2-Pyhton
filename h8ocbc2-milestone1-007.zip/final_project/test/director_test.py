import json
import config

connex_app = config.connex_app
connex_app.add_api('swagger.yml')
connex_app = connex_app.app

client = connex_app.test_client()


def test_director_read_all():
    url = '/api/director'

    response = client.get(url)
    data = json.loads(response.get_data())
    assert isinstance(data, list) is True
    assert response.status_code == 200

def test_director_read_one():
    url = '/api/director/7111'

    response = client.get(url)
    data = json.loads(response.get_data())
    assert isinstance(data, dict) is True
    assert response.status_code == 200

def test_director_create():
    url = '/api/director'
    
    mock_request_headers = {
        'Content-Type': 'application/json'
    }

    mock_request_data = {
        "department": "string",
        "gender": 0,
        "id": 7189,
        "name": "Joko Susilo",
        "uid": 15
    }
    

    response = client.post(url, data=json.dumps(mock_request_data), headers=mock_request_headers)
    assert response.status_code == 201

def test_director_delete_success():
    url = '/api/director/7189'

    response = client.delete(url)
    assert response.status_code == 200

def test_director_delete_error():
    url = '/api/director/7118'

    response = client.delete(url)
    data = json.loads(response.get_data())
    assert isinstance(data, list) is True
    assert response.status_code == 404

def test_director_put():
    url = '/api/director/7111'
    
    mock_request_headers = {
        'Content-Type': 'application/json'
    }

    mock_request_data = {
        "department": "Dept IT",
        "gender": 1,
        "name": "Yosianus",
        "uid": 1232
    }

    response = client.put(url, data=json.dumps(mock_request_data), headers=mock_request_headers)
    assert response.status_code == 200