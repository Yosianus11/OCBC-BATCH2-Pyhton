import json
import config

connex_app = config.connex_app
connex_app.add_api('swagger.yml')
connex_app = connex_app.app

client = connex_app.test_client()


def test_movie_read_all():
    url = '/api/movies'

    response = client.get(url)
    data = json.loads(response.get_data())
    assert isinstance(data, list) is True
    assert response.status_code == 200

def test_movie_top5():
    url = '/api/movies_top_popular'

    response = client.get(url)
    data = json.loads(response.get_data())
    assert isinstance(data, list) is True
    assert response.status_code == 200

def test_movie_create():
    url = '/api/director/7111/movies'
    
    mock_request_headers = {
        'Content-Type': 'application/json'
    }

    mock_request_data = {
        "id": 48414,
        "budget": 0,
        "original_title": "string",
        "overview": "string",
        "popularity": 0,
        "release_date": "string",
        "revenue": 0,
        "tagline": "string",
        "title": "string",
        "uid": 0,
        "vote_average": 0,
        "vote_count": 0
    }
    

    response = client.post(url, data=json.dumps(mock_request_data), headers=mock_request_headers)
    assert response.status_code == 201


def test_director_delete_success():
    url = '/api/director/7111/movies/48414'

    response = client.delete(url)
    assert response.status_code == 200